BLOG 2: How Much Should a Solid Wood Dining Table Actually Cost in India? — image prompts

[HERO] hero.jpg
Realistic photograph of a solid wood dining table in a bright, warm-toned Indian dining room, natural daylight, visible wood grain and joinery detail, simple table setting, no text or logos anywhere, no other brand's furniture design copied, style: authentic lifestyle/product photography, not generic stock.

[IMAGE 1] image-1.jpg
Realistic photograph showing two dining tables side by side for comparison — one simpler/lighter-toned budget-style table and one richer, thicker dark-wood premium-style table — both in a neutral studio or showroom setting with even natural light, clear visible construction differences in the wood grain and leg joinery, no text, logos, or price tags visible, style: clean comparative product photography.

[IMAGE 2] image-2.jpg
Realistic close-up photograph of a craftsman's hands using a chisel to hand-cut a mortise and tenon joint into a wooden table leg in a workshop setting, wood shavings visible on the workbench, warm natural workshop light, authentic hands-on woodworking detail, no text or logos, no other brand's furniture design copied, style: documentary craftsmanship photography.

[IMAGE 3] image-3.jpg
Realistic photograph of a finished solid wood dining table set for a meal in a bright, welcoming Indian dining room, warm earthy tones, natural daylight through a window, simple decor, no text or logos anywhere, no other brand's furniture design copied, style: warm lifestyle interior photography.
