BLOG 1: Why Your Wardrobe Drawer Sticks in July (And How to Fix It Without Damaging the Wood) — image prompts

[HERO] hero.jpg
Realistic photograph of a handcrafted solid wood wardrobe in a warmly lit Indian bedroom, one drawer pulled slightly open, natural daylight from a nearby window, visible wood grain texture, no text or logos anywhere in the image, no other brand's furniture design copied, style: authentic home-interior photography, not a stock-photo look.

[IMAGE 1] image-1.jpg
Close-up realistic photograph of a solid wood wardrobe drawer slightly jammed at an angle in its frame, showing a visible small gap where the wood has swollen against the runner, soft natural window light, warm wood tones, shallow depth of field, no text or logos, no other brand's furniture design copied, style: candid documentary-style product photography.

[IMAGE 2] image-2.jpg
Realistic photograph of a person's hand lightly rubbing a plain white candle or bar of soap along a wooden drawer runner to reduce friction, close-up on the hands and the runner track, warm workshop or home lighting, visible wood texture, no text or logos, no branding, style: instructional how-to photography, natural and unstaged looking.

[IMAGE 3] image-3.jpg
Realistic photograph of a finished solid wood wardrobe with doors closed, standing in a well-lit, tidy Indian bedroom with warm neutral tones (sand, beige, soft brown), natural daylight, a plant or soft furnishing nearby for warmth, no text or logos in the image, no other brand's furniture design copied, style: aspirational but grounded home-interior photography.
